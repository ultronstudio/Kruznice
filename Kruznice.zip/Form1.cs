﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kruznice
{
    public partial class Form1 : Form
    {
        private int circleCount;
        private int minRadius;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            // Načtěte hodnoty z textových polí
            if (int.TryParse(txtCircleCount.Text, out circleCount) && int.TryParse(txtMinRadius.Text, out minRadius))
            {
                // Překreslí okno
                this.Invalidate();
            }
            else
            {
                MessageBox.Show("Zadejte platná čísla.");
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (circleCount > 0 && minRadius > 0)
            {
                Graphics g = e.Graphics;
                int width = this.ClientSize.Width;
                int height = this.ClientSize.Height;

                // Určíme střed
                Point center = new Point(width / 2, height / 2);
                int radiusStep = 10; // Krok mezi kružnicemi

                for (int i = 0; i < circleCount; i++)
                {
                    int radius = minRadius + i * radiusStep;
                    g.DrawEllipse(Pens.Black, center.X - radius, center.Y - radius, radius * 2, radius * 2);
                }
            }
        }

        private void Form1_HelpButtonClicked(object sender, CancelEventArgs e)
        {
            MessageBox.Show($"Aplikace Kruznice\n2024 © Petr Vurm\n\nVytvořeno jako práce v hodině z předmětu PROGRAMOVÁNÍ na SPŠ Hradební.", "O aplikaci", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
